package com.cementledger.app.data.local
import androidx.room.TypeConverter
import com.cementledger.app.data.model.TransactionType
class Converters { @TypeConverter fun fromType(value: TransactionType): String = value.name; @TypeConverter fun toType(value: String): TransactionType = TransactionType.valueOf(value) }
