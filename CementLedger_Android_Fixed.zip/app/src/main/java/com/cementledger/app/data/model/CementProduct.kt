package com.cementledger.app.data.model

data class CementProduct(
    val id: String,
    val name: String,
    val type: String,
    val grade: String,
    val isBulk: Boolean
)

object CementConstants {
    val FIXED_PRODUCTS = listOf(
        CementProduct("type2_425_bulk", "سیمان نوع ۲ رده ۴۲۵ فله", "نوع ۲", "۴۲۵", true),
        CementProduct("type2_425_bag", "سیمان نوع ۲ رده ۴۲۵ کیسه", "نوع ۲", "۴۲۵", false),
        CementProduct("type2_325_bag", "سیمان نوع ۲ رده ۳۲۵ کیسه", "نوع ۲", "۳۲۵", false),
        CementProduct("type5_325_bag", "سیمان نوع ۵ رده ۳۲۵ کیسه", "نوع ۵", "۳۲۵", false),
        CementProduct("type5_425_bag", "سیمان نوع ۵ رده ۴۲۵ کیسه", "نوع ۵", "۴۲۵", false),
        CementProduct("type5_325_bulk", "سیمان نوع ۵ رده ۳۲۵ فله", "نوع ۵", "۳۲۵", true),
        CementProduct("type5_425_bulk", "سیمان نوع ۵ رده ۴۲۵ فله", "نوع ۵", "۴۲۵", true),
        CementProduct("composite_325_bag", "سیمان مرکب رده ۳۲۵ کیسه", "مرکب", "۳۲۵", false)
    )
}
