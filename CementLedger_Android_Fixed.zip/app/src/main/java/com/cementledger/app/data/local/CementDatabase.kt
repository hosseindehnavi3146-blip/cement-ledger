package com.cementledger.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.cementledger.app.data.model.TransactionEntity

@Database(entities = [TransactionEntity::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class CementDatabase : RoomDatabase() {
 abstract fun transactionDao(): TransactionDao
 companion object { @Volatile private var INSTANCE: CementDatabase? = null; fun getDatabase(context: Context): CementDatabase = INSTANCE ?: synchronized(this) { INSTANCE ?: Room.databaseBuilder(context.applicationContext, CementDatabase::class.java, "cement_ledger_database.db").build().also { INSTANCE = it } } }
}
