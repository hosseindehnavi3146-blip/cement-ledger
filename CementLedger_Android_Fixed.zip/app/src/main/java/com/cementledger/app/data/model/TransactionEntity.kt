package com.cementledger.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType {
    PURCHASE, // خرید از بورس کالا
    EXIT      // خروج از کارخانه سیمان
}

@Entity(tableName = "cement_transactions")
data class TransactionEntity(
    @PrimaryKey
    val id: String,
    val type: TransactionType,
    val productId: String,
    val productName: String,
    val date: String,            // تاریخ شمسی YYYY/MM/DD
    val amountKg: Long,          // وزن مثبت صحیح برحسب کیلوگرم
    val referenceNo: String?,    // شماره سفارش بورس یا حواله خروج
    val description: String?,    // توضیحات، راننده، پلاک و...
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
