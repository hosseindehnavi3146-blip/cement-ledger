package com.cementledger.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.cementledger.app.data.local.CementDatabase
import com.cementledger.app.data.model.CementConstants
import com.cementledger.app.data.model.TransactionEntity
import com.cementledger.app.data.model.TransactionType
import com.cementledger.app.ui.viewmodel.CementViewModel
import java.text.NumberFormat
import java.time.LocalDate
import java.util.Locale

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); val vm = CementViewModel(CementDatabase.getDatabase(this).transactionDao()); setContent { CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF246B5B), secondary = androidx.compose.ui.graphics.Color(0xFFB7791F))) { Surface(Modifier.fillMaxSize()) { CementLedgerScreen(vm) } } } } }
}

private fun fmt(n: Long): String = NumberFormat.getIntegerInstance(Locale("fa", "IR")).format(n)

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun CementLedgerScreen(vm: CementViewModel) {
 val summary by vm.productsSummary.collectAsState()
 val transactions by vm.allTransactions.collectAsState()
 var page by remember { mutableStateOf(0) }
 var showForm by remember { mutableStateOf(false) }
 var exitForm by remember { mutableStateOf(false) }
 Scaffold(topBar = { TopAppBar(title = { Text("مدیریت حواله سیمان", fontWeight = FontWeight.Bold) }) }, floatingActionButton = { Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) { FloatingActionButton(onClick = { exitForm = false; showForm = true }) { Text("+ خرید") }; FloatingActionButton(onClick = { exitForm = true; showForm = true }, containerColor = MaterialTheme.colorScheme.secondary) { Text("− خروج") } } }) { padding ->
 Column(Modifier.padding(padding).fillMaxSize().padding(12.dp)) {
  Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(selected = page == 0, onClick = { page = 0 }, label = { Text("مانده محصولات") }); FilterChip(selected = page == 1, onClick = { page = 1 }, label = { Text("تاریخچه") }) }
  if (page == 0) {
   val total = summary.sumOf { it.balanceKg }
   Card(Modifier.fillMaxWidth().padding(vertical = 8.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) { Column(Modifier.padding(16.dp)) { Text("مجموع مانده همه محصولات"); Text("${fmt(total)} کیلوگرم", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) } }
   LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(summary, key = { it.product.id }) { item -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text(item.product.name, fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text("خرید: ${fmt(item.totalPurchaseKg)} kg   |   خروج: ${fmt(item.totalExitKg)} kg"); Text("مانده: ${fmt(item.balanceKg)} کیلوگرم", color = if (item.balanceKg < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) } } } }
  } else {
   if (transactions.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("هنوز خرید یا خروجی ثبت نشده است.") }
   else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(transactions, key = { it.id }) { t -> TransactionCard(t, onDelete = { vm.deleteTransaction(t) }) } }
  }
 }
 }
 if (showForm) TransactionDialog(isExit = exitForm, onDismiss = { showForm = false }, onSave = { productId, date, amount, ref, desc -> if (exitForm) vm.addExit(productId, date, amount, ref, desc) else vm.addPurchase(productId, date, amount, ref, desc); showForm = false })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun TransactionDialog(isExit: Boolean, onDismiss: () -> Unit, onSave: (String,String,Long,String?,String?) -> Unit) {
 var selectedId by remember { mutableStateOf(CementConstants.FIXED_PRODUCTS.first().id) }
 var expanded by remember { mutableStateOf(false) }
 var date by remember { mutableStateOf(LocalDate.now().toString()) }
 var amount by remember { mutableStateOf("") }
 var ref by remember { mutableStateOf("") }
 var desc by remember { mutableStateOf("") }
 var error by remember { mutableStateOf("") }
 AlertDialog(onDismissRequest = onDismiss, title = { Text(if (isExit) "ثبت خروج از کارخانه" else "ثبت خرید از بورس") }, text = { Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
  ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) { OutlinedTextField(value = CementConstants.FIXED_PRODUCTS.first { it.id == selectedId }.name, onValueChange = {}, readOnly = true, label = { Text("محصول") }, modifier = Modifier.menuAnchor().fillMaxWidth()); ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { CementConstants.FIXED_PRODUCTS.forEach { p -> DropdownMenuItem(text = { Text(p.name) }, onClick = { selectedId = p.id; expanded = false }) } } }
  OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("تاریخ (سال-ماه-روز)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
  OutlinedTextField(value = amount, onValueChange = { amount = it.filter(Char::isDigit) }, label = { Text("مقدار به کیلوگرم") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
  OutlinedTextField(value = ref, onValueChange = { ref = it }, label = { Text(if (isExit) "شماره حواله / بارنامه (اختیاری)" else "شماره سفارش (اختیاری)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
  OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("توضیحات (اختیاری)") }, modifier = Modifier.fillMaxWidth())
  if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
 } }, confirmButton = { TextButton(onClick = { val n = amount.toLongOrNull(); if (n == null || n <= 0) error = "مقدار باید عدد صحیح مثبت باشد." else if (date.isBlank()) error = "تاریخ را وارد کنید." else onSave(selectedId, date.trim(), n, ref, desc) }) { Text("ذخیره") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

@Composable private fun TransactionCard(t: TransactionEntity, onDelete: () -> Unit) {
 var confirm by remember { mutableStateOf(false) }
 Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text(if (t.type == TransactionType.PURCHASE) "خرید" else "خروج از کارخانه", color = if (t.type == TransactionType.PURCHASE) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold); Text(t.productName, fontWeight = FontWeight.SemiBold); Text("${t.date}  •  ${fmt(t.amountKg)} کیلوگرم"); if (!t.referenceNo.isNullOrBlank()) Text("شماره: ${t.referenceNo}"); if (!t.description.isNullOrBlank()) Text(t.description); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(onClick = { confirm = true }) { Text("حذف") } } } }
 if (confirm) AlertDialog(onDismissRequest = { confirm = false }, title = { Text("حذف رکورد؟") }, text = { Text("این عملیات مانده محصول را تغییر می‌دهد.") }, confirmButton = { TextButton(onClick = { onDelete(); confirm = false }) { Text("حذف") } }, dismissButton = { TextButton(onClick = { confirm = false }) { Text("انصراف") } })
}
