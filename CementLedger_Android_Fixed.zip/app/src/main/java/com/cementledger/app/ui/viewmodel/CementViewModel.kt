package com.cementledger.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cementledger.app.data.local.TransactionDao
import com.cementledger.app.data.model.CementConstants
import com.cementledger.app.data.model.CementProduct
import com.cementledger.app.data.model.TransactionEntity
import com.cementledger.app.data.model.TransactionType
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

data class ProductBalanceUiState(
    val product: CementProduct,
    val totalPurchaseKg: Long,
    val totalExitKg: Long,
    val balanceKg: Long
)

class CementViewModel(private val dao: TransactionDao) : ViewModel() {

    val allTransactions: StateFlow<List<TransactionEntity>> = dao.getAllTransactions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // محاسبه مانده فعلی هر یک از هشت محصول (مجموع خرید منهای مجموع خروج به صورت کاملاً مستقل)
    val productsSummary: StateFlow<List<ProductBalanceUiState>> = allTransactions.map { list ->
        CementConstants.FIXED_PRODUCTS.map { product ->
            val purchases = list.filter { it.productId == product.id && it.type == TransactionType.PURCHASE }.sumOf { it.amountKg }
            val exits = list.filter { it.productId == product.id && it.type == TransactionType.EXIT }.sumOf { it.amountKg }
            ProductBalanceUiState(
                product = product,
                totalPurchaseKg = purchases,
                totalExitKg = exits,
                balanceKg = purchases - exits
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addPurchase(productId: String, date: String, amountKg: Long, ref: String?, desc: String?) {
        viewModelScope.launch {
            val product = CementConstants.FIXED_PRODUCTS.first { it.id == productId }
            val entity = TransactionEntity(
                id = UUID.randomUUID().toString(),
                type = TransactionType.PURCHASE,
                productId = productId,
                productName = product.name,
                date = date,
                amountKg = amountKg,
                referenceNo = ref?.ifBlank { null },
                description = desc?.ifBlank { null }
            )
            dao.insertTransaction(entity)
        }
    }

    fun addExit(productId: String, date: String, amountKg: Long, ref: String?, desc: String?) {
        viewModelScope.launch {
            val product = CementConstants.FIXED_PRODUCTS.first { it.id == productId }
            val entity = TransactionEntity(
                id = UUID.randomUUID().toString(),
                type = TransactionType.EXIT,
                productId = productId,
                productName = product.name,
                date = date,
                amountKg = amountKg,
                referenceNo = ref?.ifBlank { null },
                description = desc?.ifBlank { null }
            )
            dao.insertTransaction(entity)
        }
    }

    fun deleteTransaction(entity: TransactionEntity) {
        viewModelScope.launch {
            dao.deleteTransaction(entity)
        }
    }
}
