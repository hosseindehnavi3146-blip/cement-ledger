package com.cementledger.app.data.local

import androidx.room.*
import com.cementledger.app.data.model.TransactionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM cement_transactions ORDER BY date DESC, createdAt DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM cement_transactions WHERE productId = :productId ORDER BY date DESC")
    fun getTransactionsByProduct(productId: String): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(transactions: List<TransactionEntity>)

    @Update
    suspend fun updateTransaction(transaction: TransactionEntity)

    @Delete
    suspend fun deleteTransaction(transaction: TransactionEntity)

    @Query("DELETE FROM cement_transactions WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM cement_transactions")
    suspend fun clearAll()
}
